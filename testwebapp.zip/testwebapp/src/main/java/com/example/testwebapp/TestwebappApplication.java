package com.example.testwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestwebappApplication.class, args);
	}

}
